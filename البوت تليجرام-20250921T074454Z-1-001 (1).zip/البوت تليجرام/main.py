from keep_alive import keep_alive
keep_alive()
import logging
import asyncio
import pandas as pd
from telegram import Update
from telegram.ext import ApplicationBuilder, CommandHandler, MessageHandler, filters, ContextTypes
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from tempfile import NamedTemporaryFile
import time
import random
import os

TOKEN ="8455933124:AAH0vyDYGfelc7mWcGfTgvuUGa_EqQwjUYs"
ADMIN_USER_ID = 6924314113
allowed_users = {ADMIN_USER_ID}
pending_requests = set()
is_processing = False

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def create_browser():
    options = Options()
    options.add_argument("--headless")
    options.add_argument("--disable-gpu")
    options.add_argument("--no-sandbox")
    options.add_argument("--disable-dev-shm-usage")
    options.add_argument("--disable-blink-features=AutomationControlled")
    options.add_experimental_option("excludeSwitches", ["enable-automation"])
    options.add_experimental_option('useAutomationExtension', False)
    options.add_argument("--user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64)")
    driver = webdriver.Chrome(options=options)
    driver.execute_script("Object.defineProperty(navigator, 'webdriver', {get: () => undefined})")
    return driver

def check_zain_status(driver, contract_number, sheet_amount):
    try:
        time.sleep(random.uniform(0.5, 1.2))

        if str(contract_number).startswith("2"):
            url = f"https://app.sa.zain.com/en/quickpay?account={contract_number}"
        else:
            url = f"https://app.sa.zain.com/en/contract-payment?contract={contract_number}"

        driver.get(url)
        WebDriverWait(driver, 7).until(EC.presence_of_element_located((By.TAG_NAME, "body")))
        time.sleep(1)

        if "bobcmn" in driver.page_source or "TSPD" in driver.page_source:
            time.sleep(5)
            driver.refresh()
            time.sleep(3)

        element = None
        selectors = [
            (By.ID, "customAmount"),
            (By.NAME, "customAmount"),
            (By.CSS_SELECTOR, "input[id*='amount']"),
            (By.CSS_SELECTOR, "input[name*='amount']"),
            (By.XPATH, "//input[contains(@id, 'amount')]"),
            (By.XPATH, "//input[contains(@name, 'amount')]"),
            (By.XPATH,"//span[contains(text(),'Amount')]/followingsibling::input")
        ]

        for selector_type, selector in selectors:
            try:
                element = WebDriverWait(driver, 6).until(
                    EC.visibility_of_element_located((selector_type, selector))
                )
                break
            except:
                continue

        if not element:
            return f"❌ لم يتم العثور على حقل المبلغ للعقد: {contract_number}"

        amount_value = element.get_attribute("value") or ""
        amount_value_clean = amount_value.replace(",", "").replace(" ", "").replace("ريال", "").replace("SR", "")

        try:
            site_amount = float(amount_value_clean)
            sheet_amount = float(sheet_amount)

            if site_amount == 0:
                return "✅ مسددة بالكامل"
            elif site_amount > sheet_amount:
                return f"📌 غير مسددة - الموقع: {site_amount} ريال | الملف: {sheet_amount} ريال"
            elif site_amount < sheet_amount:
                return f"⚠️ مختلف - الموقع: {site_amount} ريال | الملف: {sheet_amount} ريال"
            else:
                return f"📌 غير مسددة - {site_amount} ريال"
        except:
            return f"❌ خطأ في تحويل المبلغ: {amount_value_clean}"

    except Exception as e:
        return f"❌ خطأ للعقد {contract_number}: {str(e)}"

def is_authorized(user_id):
    return user_id in allowed_users

async def request_access(update: Update):
    user = update.effective_user
    pending_requests.add(user.id)
    await update.message.reply_text("🚫 غير مصرح لك. تم إرسال طلب للمشرف.")
    await update.get_bot().send_message(
        chat_id=ADMIN_USER_ID,
        text=f"طلب دخول من @{user.username or 'غير معروف'} (ID: {user.id})"
    )

async def approve_user(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.effective_user.id != ADMIN_USER_ID:
        return await update.message.reply_text("🚫 هذا الأمر للمشرف فقط.")
    if not context.args:
        return await update.message.reply_text("❗ استخدم الأمر هكذا: /approve 123456789")
    try:
        user_id = int(context.args[0])
        allowed_users.add(user_id)
        pending_requests.discard(user_id)
        await update.message.reply_text(f"✅ تم السماح للمستخدم {user_id}")
        await context.bot.send_message(chat_id=user_id, text="✅ تم قبول طلبك.")
    except Exception as e:
        await update.message.reply_text(f"❌ خطأ: {str(e)}")

async def list_requests(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.effective_user.id != ADMIN_USER_ID:
        return await update.message.reply_text("🚫 هذا الأمر للمشرف فقط.")
    if not pending_requests:
        return await update.message.reply_text("📭 لا توجد طلبات حالياً.")
    text = "طلبات الإذن:\n" + "\n".join([f"- {uid}" for uid in pending_requests])
    await update.message.reply_text(text)

async def handle_document(update: Update, context: ContextTypes.DEFAULT_TYPE):
    global is_processing
    user_id = update.effective_user.id

    if not is_authorized(user_id):
        await request_access(update)
        return

    if is_processing:
        await update.message.reply_text("⏳ المعالجة جارية بالفعل...")
        return

    is_processing = True

    file = update.message.document
    if not file.file_name.endswith(('.xlsx', '.xls')):
        await update.message.reply_text("❌ فقط ملفات Excel مقبولة.")
        is_processing = False
        return

    await update.message.reply_text(
        "📥 <b>تم استلام الملف بنجاح</b>\n"
        "⏳ جاري معالجة العقود...",
        parse_mode="HTML"
    )

    telegram_file = await file.get_file()
    with NamedTemporaryFile(delete=False, suffix=".xlsx") as tf:
        await telegram_file.download_to_drive(tf.name)
        temp_path = tf.name

    try:
        df = pd.read_excel(temp_path)
        if df.empty or 'رقم الحساب' not in df.columns or 'مبلغ المديونية' not in df.columns:
            await update.message.reply_text(
                "❌ <b>الملف غير صالح</b>\n"
                "⚠️ يجب أن يحتوي على الأعمدة: <code>رقم الحساب</code> و <code>مبلغ المديونية</code>",
                parse_mode="HTML"
            )
            is_processing = False
            return

        df['حالة السداد'] = '...'

        driver = create_browser()
        total = len(df)
        processed, failed = 0, 0
        chunk_results = []

        # أول رسالة للتقدم
        progress_message = await update.message.reply_text(
            "📊 <b>جاري فحص العقود...</b>\n[░░░░░░░░░░] 0%",
            parse_mode="HTML"
        )

        try:
            for idx, row in df.iterrows():
                await asyncio.sleep(0)

                if not is_processing:
                    await update.message.reply_text("⛔ <b>تم الإيقاف.</b>", parse_mode="HTML")
                    break

                contract = str(row['رقم الحساب']).strip()
                try:
                    raw_amount = str(row['مبلغ المديونية']).replace(",", "").replace("ريال", "").replace("SR", "").strip()
                    sheet_amount = float(raw_amount)
                except:
                    df.at[idx, 'حالة السداد'] = "❌ مبلغ غير صالح"
                    continue

                if not contract or len(contract) < 5:
                    df.at[idx, 'حالة السداد'] = "❌ رقم غير صالح"
                    continue

                status = None
                for attempt in range(2):
                    status = check_zain_status(driver, contract, sheet_amount)
                    if not status.startswith("❌") and not status.startswith("⏱️"):
                        break
                    time.sleep(2)

                df.at[idx, 'حالة السداد'] = status
                processed += 1
                if status.startswith("❌"):
                    failed += 1

                # تحديث الرسالة الرئيسية كل 5 عملاء
                if processed % 5 == 0 or idx == total - 1:
                    progress = int((processed / total) * 100)
                    bar_filled = progress // 10
                    bar_empty = 10 - bar_filled
                    bar = "█" * bar_filled + "░" * bar_empty

                    await progress_message.edit_text(
                        f"📊 <b>جاري فحص العقود...</b>\n"
                        f"تم فحص <code>{processed}</code> من <code>{total}</code>\n"
                        f"[{bar}] {progress}%",
                        parse_mode="HTML"
                    )

                # رسالة جديدة كل 50 عميل
                if processed % 50 == 0 or idx == total - 1:
                    start_range = idx + 1 - 49 if processed >= 50 else 1
                    end_range = idx + 1
                    await update.message.reply_text(
                        f"✅ <b>تم الانتهاء من العقود {start_range} → {end_range}</b>",
                        parse_mode="HTML"
                    )

                # حفظ chunk كل 50 عميل
                chunk_results.append({
                    "رقم الحساب": contract,
                    "مبلغ المديونية": sheet_amount,
                    "حالة السداد": status
                })

                if len(chunk_results) == 50 or idx == total - 1:
                    chunk_df = pd.DataFrame(chunk_results)
                    with NamedTemporaryFile(delete=False, suffix=".xlsx") as chunk_file:
                        chunk_df.to_excel(chunk_file.name, index=False)
                        chunk_filename = chunk_file.name

                    with open(chunk_filename, "rb") as f:
                        await update.message.reply_document(
                            document=f,
                            filename=f"نتائج_{idx+1 - len(chunk_results) + 1}_الى_{idx+1}.xlsx"
                        )
                    os.remove(chunk_filename)
                    chunk_results.clear()

        finally:
            driver.quit()

        # حساب الإحصائيات
        paid = df['حالة السداد'].str.startswith("✅").sum()
        unpaid = df['حالة السداد'].str.startswith("📌").sum()
        different = df['حالة السداد'].str.startswith("⚠️").sum()
        errors = df['حالة السداد'].str.startswith("❌").sum()
        total = len(df)

        summary = (
            f"📊 <b>النتائج النهائية</b>\n\n"
            f"🔢 <b>إجمالي العقود:</b> <code>{total}</code>\n\n"
            f"✅ <b>مسددة:</b> <code>{paid}</code>\n"
            f"📌 <b>غير مسددة:</b> <code>{unpaid}</code>\n"
            f"⚠️ <b>مختلف:</b> <code>{different}</code>\n"
            f"❌ <b>أخطاء:</b> <code>{errors}</code>\n\n"
            f"🎉 <b>مبروك يا عم.. خلصنا كله ✅</b>"
        )

        # إرسال الملف النهائي
        with NamedTemporaryFile(delete=False, suffix=".xlsx") as final_file:
            df.to_excel(final_file.name, index=False)
            final_filename = final_file.name

        with open(final_filename, "rb") as f:
            await update.message.reply_document(
                document=f,
                filename="النتائج_النهائية.xlsx"
            )

        await progress_message.edit_text(summary, parse_mode="HTML")

    except Exception as e:
        await update.message.reply_text(
            f"❌ <b>حدث خطأ أثناء الفحص:</b>\n<code>{e}</code>",
            parse_mode="HTML"
        )
        logger.error(str(e))

    is_processing = False

async def cancel(update: Update, context: ContextTypes.DEFAULT_TYPE):
    global is_processing
    if is_authorized(update.effective_user.id):
        is_processing = False
        await update.message.reply_text("✅ تم إيقاف الفحص.")
    else:
        await request_access(update)

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if is_authorized(update.effective_user.id):
        await update.message.reply_text("📑 أرسل ملف Excel يحتوي على الأعمدة: <code>رقم الحساب</code> و <code>مبلغ المديونية</code>.", parse_mode="HTML")
    else:
        await request_access(update)

def main():
    app = ApplicationBuilder().token(TOKEN).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("cancel", cancel))
    app.add_handler(CommandHandler("approve", approve_user))
    app.add_handler(CommandHandler("requests", list_requests))
    app.add_handler(MessageHandler(filters.Document.ALL, handle_document))
    app.run_polling()

if __name__ == "__main__":
    main()
